#include <iostream>
#include <cstdlib> // importado para conseguir limpar o terminal com a syntaxe "system("clear");"

int main(){
  int n = 0;
  int y;

  system("clear");

  std::cout << "\n====== FAÇA UM DIAMANTE MANEIRO! ======\n"
            << "\n"
            << "Digite o tamanho que o diamante terá: ";
  std::cin >> y;

  if(y < 3){
    std::cout << "Digite um tamanho maior ou igual a 3.";
    return 0;
  }else{

    system("clear");

    for(;n<y;n++){
      int quantidadeEspaço = y - 1;

      while(quantidadeEspaço >= n){
        std::cout << " ";
        quantidadeEspaço --;
      }

      for (size_t i = 0; i < n; i++){
        std::cout << ".";
      }

      for (size_t i = 0; i <= n; i++){
        std::cout << ".";
      }

      std::cout << std::endl;
    }
    for(;n<=y;n--){
      if(n == -1){
        std::cout << "\n\n[SUCESSO] DIAMANTE GERADO!\n\n";
        return 0;
      }else{
        int quantidadeEspaço = y - 1;

        while(quantidadeEspaço >= n){
          std::cout << " ";
          quantidadeEspaço --;
        }

        for (size_t i = 0; i < n; i++){
          std::cout << ".";
        }

        for (size_t i = 0; i <= n; i++){
          std::cout << ".";
        }

        std::cout << std::endl;
      }
    }
  }
  return 0;
}
