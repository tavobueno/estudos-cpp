#include <iostream>

int main(){
  int n = 0;
  int y;

  system("clear");

  std::cout << "\n====== FAÇA UM TRIÂNGULO MANEIRO! ======\n"
            << "\n"
            << "Digite a quantidade de linhas que o triângulo terá!"
            << "\n"
            << "-> ";
  std::cin >> y;

  if(y < 3){
    std::cout << "Digite um tamanho maior ou igual a 3.";
  }else{

    system("clear");

    for(;n<y;n++){
      int quantidadeEspaço = y - 1;

      while(quantidadeEspaço >= n){
        std::cout << " ";
        quantidadeEspaço --;
      }

      for (size_t i = 0; i < n; i++){
        std::cout << ".";
      }

      for (size_t i = 0; i <= n; i++){
        std::cout << ".";
      }

      std::cout << std::endl;
    }

    std::cout << "\n\n[SUCESSO] TRIÂNGULO GERADO!\n";
  }

  std::cout << std::endl;

  return 0;
}
