#include <iostream>

int main(){
  std::string nomeUser;

  nomeUser = "gustavo";

  std::cout << "Olá mundo!" << std::endl;
  std::cout << nomeUser;

  return 0;
}
