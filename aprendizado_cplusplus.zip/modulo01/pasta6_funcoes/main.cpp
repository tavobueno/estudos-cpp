#include <iostream>

int calculo(int x, int n){
  int i = 1;
  while (i < n){
    x = x * x;
    i++;
  }

  return x;

}

int main(){
  int x;
  int y;
  std::cout << "Digite um número: ";
  std::cin >> x;
  std::cout << "Esse numero será elevado a: ";
  std::cin >> y;


  std::cout << "\n\n" << "Resultado: " << calculo(x, y) << "\n";

  return 0;
}
